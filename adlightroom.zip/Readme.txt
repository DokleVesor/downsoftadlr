MANUAL :
1. Unzip all files from archive
2. Run file: SoftwareSetupFile.exe